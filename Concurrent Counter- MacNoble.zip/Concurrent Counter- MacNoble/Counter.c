#include <stdio.h>
#include <pthread.h>

typedef struct __counter_t {
    int value; 
}

counter_t;

counter_t init(counter_t c) {
    c.value = 0;
    return c;
}


void *increment(counter_t *c) {
    c->value++;
}

void decrement(counter_t *c) {
    c->value--;
}

int get(counter_t *c) {
    return c->value;
}


void *countUp (void *arg) {
    int i;
    int stop = 1e6;
    counter_t *counter = (counter_t* ) arg;
    for(i=0;i<stop; i++){
        increment(counter);
    }
    
    return NULL;
}
    


int main (){
    //Creating instance of counter and initializing counter.
    counter_t CounterUp;
    CounterUp= init(CounterUp);
    
    //Creating threads for execution
    pthread_t p1, p2, p3, p4, p5;
    
    //Printing intial value of counter
    printf("Starting value of (counter = %d)\n", get(&CounterUp));
    pthread_create(&p1, NULL, countUp, &CounterUp);
    pthread_create(&p2, NULL, countUp, &CounterUp);
    pthread_create(&p3, NULL, countUp, &CounterUp);
    pthread_create(&p4, NULL, countUp, &CounterUp);
    pthread_create(&p5, NULL, countUp, &CounterUp);
    
    //Waiting for child threads to complete
    pthread_join(p1, NULL);
    pthread_join(p2, NULL);
    pthread_join(p3, NULL);
    pthread_join(p4, NULL);
    pthread_join(p5, NULL);
    
    //Prining final value of counter (with indeterminate output)
    printf("Closing value (counter = %d)\n", get(&CounterUp));
    return 0;
    
}
    